/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.filedemo.apps.controller;

import com.filedemo.apps.formbean.Student;
import java.io.File;
import java.io.InputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author MyPc
 */
public class FileHandler extends MultiActionController{
    
    public ModelAndView getForm(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv = new ModelAndView("studentform");
        return mv;
    }
    
    public ModelAndView uploadFile(HttpServletRequest request,HttpServletResponse response,Student formbean){
        ModelAndView mv = new ModelAndView("imagesuccess");
        try {
            //"upload" is Folder name Where we upload our file
            //You Can Put Your Upload Path //Here it is upload in build/web/upload/
            String uploadPath =  getServletContext().getRealPath("/").concat("upload\\");
            
            
            //Get Uploaded File name && You can insert this name to database
            String fileName =  uploadFile(formbean.getProfile(),uploadPath);
            
            String studentName = formbean.getName();
            
            System.out.println("FILE NAME : "+fileName);
        } catch (Exception e) {
            System.out.println("Ex : "+e.getMessage());
        }
        
        return mv;
    }
    /*
        File Upload Function  (Common For All Your Files Upload)
        Return File Name After Upload Successfully...!!!
    */
    public String uploadFile(MultipartFile multipartfile,String uploadPath) {
        
        try {
            System.out.println("PATH : "+uploadPath);
            File file  =  new File(uploadPath+multipartfile.getOriginalFilename());
            multipartfile.transferTo(file);
            return multipartfile.getOriginalFilename();
        } catch (Exception e) {
            System.out.println("Ex : "+e.getMessage());
            return null;
        }                
    }
}
