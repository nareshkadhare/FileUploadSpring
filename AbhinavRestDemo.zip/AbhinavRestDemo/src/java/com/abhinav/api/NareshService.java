/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abhinav.api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author MYPC
 */
@Path("naresh")
public class NareshService {
    
     @GET
    @Path("name")
    public String getService() {
        return "Naresh ki Service";
    }
}
